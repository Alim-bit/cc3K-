#ifndef DWARF_H
#define DWARF_H
#include <string>

#include "playerChar.h"

class Dwarf : public PlayerChar {

public:
    Dwarf();
    // void playerAbility() override;
};

#endif
