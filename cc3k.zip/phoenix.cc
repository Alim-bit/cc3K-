#include "phoenix.h"

Phoenix::Phoenix() : Enemy("Phoenix", 'X', 50, 50, 35, 20) {}

