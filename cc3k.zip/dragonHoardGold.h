#ifndef DRAGONHOARDGOLD_H
#define DRAGONHOARDGOLD_H

#include "item.h"

class DragonHoardGold : public Item {
public:
    DragonHoardGold();
};

#endif // DRAGONHOARDGOLD_H
