#include "merchantHoardGold.h"
#include <iostream>

MerchantHoardGold::MerchantHoardGold()
    : Item("MH", 'G', 4) {}

