#ifndef GOBLIN_H
#define GOBLIN_H
#include <string>

#include "enemy.h"

class Goblin : public Enemy {

public:
    Goblin();

};

#endif
