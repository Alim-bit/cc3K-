#ifndef NORMALGOLD_H
#define NORMALGOLD_H

#include "item.h"

class NormalGold : public Item {
public:
    NormalGold();
};

#endif // NORMALGOLD_H

