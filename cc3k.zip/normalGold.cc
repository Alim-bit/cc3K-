#include "normalGold.h"
#include <iostream>

NormalGold::NormalGold() : Item("NG", 'G', 1) {}


