#include "dwarf.h"

Dwarf::Dwarf() : PlayerChar("Dwarf", 100, 100, 20, 30, 1) {}

// void Dwarf::playerAbility() { /*implement */ }
