#include "smallHoardGold.h"
#include <iostream>

SmallHoardGold::SmallHoardGold()
    : Item("SH", 'G', 2) {}


