#ifndef TROLL_H
#define TROLL_H
#include <string>

#include "enemy.h"

class Troll : public Enemy {

public:
    Troll();

};

#endif
