#include "orc.h"

Orc::Orc() : PlayerChar("Orc", 180, 180, 30, 25, 1) {}

// void Orc::playerAbility() { /*implement */ }

