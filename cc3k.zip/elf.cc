#include "elf.h"

Elf::Elf() : PlayerChar("Elf", 140, 140, 30, 10, 1) {}

// void Elf::playerAbility() { /*implement */ }
