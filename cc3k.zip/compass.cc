#include "compass.h"
#include <iostream>

Compass::Compass()
    : Item("C", 'C', 10) {}

