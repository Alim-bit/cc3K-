#ifndef ELF_H
#define ELF_H
#include <string>

#include "playerChar.h"

class Elf : public PlayerChar {

public:
    Elf();
    // void playerAbility() override;
};

#endif
