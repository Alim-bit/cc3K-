#ifndef MERCHANTHOARDGOLD_H
#define MERCHANTHOARDGOLD_H

#include "item.h"

class MerchantHoardGold : public Item {
public:
    MerchantHoardGold();
};

#endif // MERCHANTHOARDGOLD_H

