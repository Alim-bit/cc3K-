#include "human.h"

Human::Human() : PlayerChar("Human", 140, 140, 20, 20, 1) {}

// void Human::playerAbility() {}
