#ifndef HUMAN_H
#define HUMAN_H
#include <string>

#include "playerChar.h"

class Human : public PlayerChar {

public:
    Human();
    // void playerAbility() override;
};

#endif
