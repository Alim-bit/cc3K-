#include "dragonHoardGold.h"
#include <iostream>

DragonHoardGold::DragonHoardGold()
    : Item("DH", 'G', 6) {}
