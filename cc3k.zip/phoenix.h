#ifndef PHOENIX_H
#define PHOENIX_H
#include <string>

#include "enemy.h"

class Phoenix : public Enemy {

public:
    Phoenix();

};

#endif

