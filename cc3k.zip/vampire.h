#ifndef VAMPIRE_H
#define VAMPIRE_H
#include <string>

#include "enemy.h"

class Vampire : public Enemy {

public:
    Vampire();

};

#endif
