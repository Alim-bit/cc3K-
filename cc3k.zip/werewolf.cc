#include "werewolf.h"

Werewolf::Werewolf() : Enemy("Werewolf", 'W', 120, 120, 30, 5) {}
