#include "vampire.h"

Vampire::Vampire() : Enemy("Vampire", 'V', 50, 50, 25, 25) {}
