#ifndef ORC_H
#define ORC_H
#include <string>

#include "playerChar.h"

class Orc : public PlayerChar {

public:
    Orc();
    // void playerAbility() override;
};

#endif

