#include "troll.h"

Troll::Troll() : Enemy("Troll", 'T', 120, 120, 30, 5) {}
