#ifndef WEREWOLF_H
#define WEREWOLF_H
#include <string>

#include "enemy.h"

class Werewolf : public Enemy {

public:
    Werewolf();

};

#endif
