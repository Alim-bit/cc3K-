#include "barrierSuit.h"
#include <iostream>

BarrierSuit::BarrierSuit() : Item("BS", 'B', 11) {}


