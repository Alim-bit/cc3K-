#include "goblin.h"

Goblin::Goblin() : Enemy("Goblin", 'N', 70, 70, 5, 10) {}
